//
//  complex.hpp
//  lab1
//
//  Created by Matvey on 02.04.2018.
//  Copyright © 2018 Matvey. All rights reserved.
//

#ifndef complex_hpp
#define complex_hpp

#include <stdio.h>

#endif /* complex_hpp */
