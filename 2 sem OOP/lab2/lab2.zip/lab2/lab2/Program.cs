﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestConsoleApplication
{
    class Program
    {
        public static string CreateFio(string secName, string Name, string surName)
        {
            string fio = secName + " " + Name + " " + surName;
            return fio;
        }

        public static string CreateFioInitials(string secName, string Name, string surName)
        {
            string fio = secName + " " + Name.Substring(0, 1) + ". " + surName.Substring(0, 1) + ".";
            return fio;
        }


        static void Main(string[] args)
        {


            string name = "Матвей";
            string otchestvo = "Романович";
            string surname = "Крючков";


            string name2 = "Александр";
            string otchestvo2 = "Анатольевич";
            string surname2 = "Лобанов";

            System.Console.WriteLine(CreateFio(surname, name, otchestvo));
            System.Console.WriteLine(CreateFioInitials(surname, name, otchestvo));
            System.Console.WriteLine(CreateFio(surname2, name2, otchestvo2));
            System.Console.WriteLine(CreateFioInitials(surname2, name2, otchestvo2));

            System.Console.ReadLine();

        }

    }
}