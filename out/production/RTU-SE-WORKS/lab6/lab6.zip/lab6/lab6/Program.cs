﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6
{
    abstract class Animal
    {
        abstract public string Type();
        abstract public bool live();
        abstract public string nickname();
        static void Main()
        {
            Dog dog = new Dog("Пудель", "Бобик", true);
            Console.WriteLine("Порода: {0} , Кличка: {1} , Жив: {2}", dog.Type(), dog.nickname(), dog.live());

            Cat cat = new Cat("Мейн-кун", "Мурка", true);
            Console.WriteLine("Порода: {0} , Кличка: {1} , Жив: {2}", cat.Type(), cat.nickname(), cat.live());


            Console.ReadKey();
        }

    }
    class Dog : Animal
    {
        public string breed;
        public bool flag;
        public string klik;
        public Dog(string br, string kl, bool f)
        {
            breed = br;
            klik = kl;
            flag = f;
        }

        public override string Type()
        {
            return breed;
        }
        public override string nickname()
        {
            return klik;
        }
        public override bool live()
        {
            return flag;
        }
    }
    class Cat : Animal
    {
        public string breed;
        public bool flag;
        public string klik;
        public Cat(string br, string kl, bool f)
        {
            breed = br;
            klik = kl;
            flag = f;
        }

        public override string Type()
        {
            return breed;
        }
        public override string nickname()
        {
            return klik;
        }
        public override bool live()
        {
            return flag;
        }
    }

}